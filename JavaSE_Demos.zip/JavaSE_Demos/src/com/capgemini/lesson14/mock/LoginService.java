package com.capgemini.lesson14.mock;

public interface LoginService {
boolean login(String username, String password);
}
